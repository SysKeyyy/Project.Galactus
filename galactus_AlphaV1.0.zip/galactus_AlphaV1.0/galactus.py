from PyQt5.QtWidgets import *
from PyQt5.QtWebEngineWidgets import *
from PyQt5.QtCore import *
import sys
# imports

class Browser_window(QMainWindow):
	def __init__(self):
		super(QMainWindow, self).__init__()
		self.browser = QWebEngineView()
		self.browser.setUrl(QUrl('https://duckduckgo.com'))
		self.setCentralWidget(self.browser)
		self.showMaximized()

		# navigation
		navbar = QToolBar()
		self.addToolBar(navbar)

		navi_back = QAction('<', self)
		navi_back.triggered.connect(self.browser.back)
		navbar.addAction(navi_back)

		navi_forward = QAction('>', self)
		navi_forward.triggered.connect(self.browser.forward)
		navbar.addAction(navi_forward)

		reload_butn = QAction('Reload', self)
		reload_butn.triggered.connect(self.browser.reload)
		navbar.addAction(reload_butn)


app = QApplication(sys.argv)
QApplication.setApplicationName('Galactus Web-browser beta v1.0')
window = Browser_window()
app.exec_()

